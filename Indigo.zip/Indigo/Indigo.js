$("#expand-post").click(function () {
    $(this).hide();
    $("#extra-text").show();
});